# notedir
to my student note
